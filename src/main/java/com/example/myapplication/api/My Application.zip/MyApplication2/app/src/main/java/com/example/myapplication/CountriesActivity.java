package com.example.myapplication;

import android.os.Bundle;
import android.os.Handler;

import android.view.View;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.models.CountryModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CountriesActivity extends AppCompatActivity implements OnDataPassedListener{
    private List<CountryModel> mStringList=new ArrayList<>();
    List<CountryModel> wholecountriesList;
    private int mLoadedItems = 0;
    private CountryAdapter mSampleAdapter;
    ProgressBar itemProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        String key=getIntent().getExtras().getString("params");
        wholecountriesList = CountryTon.getInstance().getmCountryTon().get(key);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(CountriesActivity.this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        RecyclerView recyclerView=findViewById(R.id.recycler_view);
        itemProgressBar=findViewById(R.id.item_progress_bar);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(CountriesActivity.this, DividerItemDecoration.VERTICAL));
       // mStringList = new ArrayList<>();
        mSampleAdapter = new CountryAdapter(CountriesActivity.this);
        mSampleAdapter.setMyList(mStringList);
        recyclerView.setAdapter(mSampleAdapter);
        addDataToList();
        recyclerView.addOnScrollListener(new EndlessRecyclerOnScrollListener() {
            @Override
            public void onLoadMore() {
                addDataToList();
            }
        });
    }

    private void addDataToList() {
        itemProgressBar.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                int lSize=0, lReminder=wholecountriesList.size();
                if(mLoadedItems != 0) {
                    lReminder = wholecountriesList.size() % mLoadedItems;
                }
                if(lReminder >= 10){
                    lSize=10;
                }
                else
                    lSize = lReminder;
                for (int i = 0; i <= lSize; i++) {
                    mStringList.add(wholecountriesList.get(mLoadedItems));
                    mLoadedItems++;
                }
                mSampleAdapter.notifyDataSetChanged();
                itemProgressBar.setVisibility(View.GONE);
            }
        }, 1500);

    }

    @Override
    public void OnDataPassed(String paramString) {

    }
}
