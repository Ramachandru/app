package com.example.myapplication;

public interface OnDataPassedListener {
   public void OnDataPassed(String paramString);
}
